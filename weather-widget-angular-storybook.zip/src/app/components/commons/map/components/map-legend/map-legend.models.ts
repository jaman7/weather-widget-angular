export interface ILegend {
  title: string;
  gradient: string;
  dividers: number[];
}
