export type DocOpenTypes = 'SHOW' | 'ADD' | 'EDIT';
