import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-current-weather',
  templateUrl: './current-weather.component.html',
})
export class CurrentWeatherComponent {
  @Input() weatherData;
}
