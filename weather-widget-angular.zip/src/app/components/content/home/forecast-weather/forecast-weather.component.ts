import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-forecast-weather',
  templateUrl: './forecast-weather.component.html',
})
export class ForecastWeatherComponent {
  @Input() forecast = [];
}
