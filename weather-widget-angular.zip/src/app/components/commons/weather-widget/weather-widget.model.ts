export interface IWeatherData {
  id?: number;
  city?: string;
  temp?: number;
  description?: string;
  icon?: string;
}
