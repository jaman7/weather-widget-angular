export interface ISearchData {
  city?: string;
  latitude?: number;
  longitude?: number;
}
