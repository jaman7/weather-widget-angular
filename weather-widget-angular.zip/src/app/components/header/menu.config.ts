import { IMenuConfig } from './menu.models';

export const menuConfig = (): IMenuConfig[] => [
  { name: 'home', title: 'menu.home.title' },
  { name: 'example', title: 'menu.example.title' },
  { name: 'example', title: 'menu.example.title' },
  { name: 'example', title: 'menu.example.title' },
  { name: 'example', title: 'menu.example.title' },
];
