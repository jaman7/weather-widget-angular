export interface LanguageState {
  key: string;
}

export type LanguageType = 'pl' | 'en';
