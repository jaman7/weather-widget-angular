export const environment = {
  production: false,

  SERVER_BASE_URL: 'https://localhost:1337',

  SERVER_API_URL: 'https://localhost:1337/api',
};
