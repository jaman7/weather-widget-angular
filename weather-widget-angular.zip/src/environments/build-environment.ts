
const buildEnvironment = {
  production: true,
  version: '1.0.0',
  buildTimestamp: '2024-11-19T10:06:37.856Z'
};

export default buildEnvironment;
