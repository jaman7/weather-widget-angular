/***************************************************************************************************
 * Zone JS is required by Angular itself.
 */
import 'zone.js'; // Included with Angular CLI.

/***************************************************************************************************
 * APPLICATION IMPORTS
 * Add any additional imports required by your application below.
 */

// Example: If you use `Intl` for localization in older environments (not required in most modern browsers)
// import 'intl';
// import 'intl/locale-data/jsonp/en';
